# Non-empty folder

Distance range: 3-10m
